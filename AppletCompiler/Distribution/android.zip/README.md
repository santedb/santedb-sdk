# santedb-dc-android
SanteDB Disconnected Client Android Application

## Have a Bug?

You can file bugs related to the SanteDB dCDR Android Application on the [SanteDB dCDR Android BugZilla](https://bugzilla.fyfesoftware.ca/describecomponents.cgi?product=SanteDB%20dCDR%20Android%20App)
